package com.question.PracticeQuestionMovie;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PracticeQuestionMovieApplicationTests {

	@Test
	void contextLoads() {
	}

}
